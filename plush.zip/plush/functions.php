<?php
/**
 * Plush child theme: an IDA-accredited detailing studio and body shop in Karen, booked like a shop.
 * Services are products priced by vehicle class (the global "Vehicle class" attribute); the cart is the booking,
 * and checkout asks for the car, studio drop-off or VIP pick-up, the date and the drop-off time.
 */

const PL_WHATSAPP = '254712117522'; // The number on their Google listing; WhatsApp on it is a PLACEHOLDER to confirm.
const PL_PHONE    = '0712 117 522';
const PL_TEL      = '+254712117522';
const PL_IG       = 'https://www.instagram.com/plush.kenya/';
const PL_MAPS     = 'https://maps.google.com/?q=-1.316398,36.718880';
const PL_HOURS    = 'Mon–Fri 9 am–5 pm · Sat 9 am–2 pm · Sun closed';
const PL_FONTS    = 'https://fonts.googleapis.com/css2?family=Saira:ital,wght@0,500;0,600;0,700;0,800;0,900;1,800;1,900&family=Inter:wght@400;500;600;700&display=swap';

// Drop-off at the studio, or the VIP pick-up the brief asks for. Pick-up areas and fees are PLACEHOLDERS.
const PL_PLACES = [ 'studio' => 'Drop-off at our Karen studio', 'valet' => 'VIP covered pick-up & return' ];
const PL_AREAS  = [
	'none'       => 'No pick-up: I\'ll drop it off',
	'karen'      => 'Karen & Hardy',
	'langata'    => 'Lang\'ata & Otiende',
	'ngong-road' => 'Ngong Road, Kilimani & Lavington',
	'westlands'  => 'Westlands, Runda & Gigiri',
	'upper-hill' => 'Upper Hill & CBD',
	'ngong'      => 'Ngong, Kiserian & Rongai',
	'other'      => 'Elsewhere in Nairobi (fee quoted)',
];
const PL_SLOTS = [ '9am' => '9:00 am', '11am' => '11:00 am', '1pm' => '1:00 pm (weekdays)', '3pm' => '3:00 pm (weekdays)' ];

// Estimator packages (the three tiers in the brief): the services (and second option) each one adds.
const PL_TIERS = [
	'essential'   => [ 'Essential Detail & Engine Steam', 'Exterior detail & decontamination + steamed engine bay', [ [ 'exterior-detail-decon', null ], [ 'steamed-engine-bay', null ] ] ],
	'restoration' => [ 'Full Body Paint Restoration', 'Signature full detail + 2-stage Rupes paint correction', [ [ 'full-detail', null ], [ 'paint-correction', '2-stage correction' ] ] ],
	'wrap'        => [ 'Custom Vinyl Wrap Package', 'Full colour-change wrap in gloss, satin or matte', [ [ 'colour-change-wrap', 'Gloss, satin or matte' ] ] ],
];
// Estimator add-ons (the brief's list): [ service, option, label ]. Vehicle-priced services follow the chosen class.
const PL_ADDONS = [
	[ 'steamed-engine-bay', null, 'Steamed engine bay detailing & dressing' ],
	[ 'headlight-restoration', null, 'Headlight restoration & UV protection' ],
	[ 'partial-wrap-accents', 'Chrome delete (window trims)', 'Vinyl wrap trim accents (chrome delete)' ],
	[ 'ceramic-coating', '1 year', 'Gyeon ceramic paint coating layer (1 year)' ],
	[ 'ozone-odour-removal', null, 'Ozone odour removal & disinfection' ],
	[ 'leather-deep-clean', null, 'Leather deep clean & treatment' ],
];

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'pl-fonts', PL_FONTS, [], null );
	wp_enqueue_style( 'pl', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'pl', $uri . '/assets/pl.js', [], filemtime( $dir . '/assets/pl.js' ), true );
	wp_localize_script( 'pl', 'PL', [
		'store'    => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'shop'     => esc_url_raw( wc_get_page_permalink( 'shop' ) ),
		'checkout' => esc_url_raw( wc_get_checkout_url() ),
		'home'     => esc_url_raw( home_url( '/' ) ),
		'wa'       => PL_WHATSAPP,
		'est'      => is_front_page() || is_page( 'estimator' ) ? pl_estimator_data() : null,
	] );
} );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'pl-fonts', PL_FONTS, [], null );
} );
add_action( 'after_setup_theme', function () {
	add_editor_style( 'style.css' );
} );

// Vehicle pages (/vehicle/executive-suv/) need rewrite rules made after the attribute exists.
add_action( 'init', function () {
	if ( get_option( 'pl_rewrites' ) !== '1' && taxonomy_exists( 'pa_vehicle' ) ) {
		flush_rewrite_rules();
		update_option( 'pl_rewrites', '1' );
	}
}, 99 );

// WooCommerce's symbol for Kenyan shillings is "KSh", the way businesses here write it.
add_filter( 'woocommerce_currency_symbol', fn( $s, $c ) => $c === 'KES' ? 'KSh' : $s, 10, 2 );

function pl_wa_link( $text = '' ) {
	return 'https://wa.me/' . PL_WHATSAPP . ( $text !== '' ? '?text=' . rawurlencode( $text ) : '' );
}

function pl_money( $amount ) {
	return 'KSh ' . number_format( (float) $amount );
}

function pl_product( $slug ) {
	$post = get_page_by_path( $slug, OBJECT, 'product' );
	return $post ? wc_get_product( $post->ID ) : null;
}

function pl_is_quote( $product_id ) {
	return get_post_meta( $product_id, '_pl_quote', true ) === 'yes';
}

function pl_clip_url( $name ) {
	return $name ? get_stylesheet_directory_uri() . '/assets/clips/' . $name . '.mp4' : '';
}

const PL_WA_ICON = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.3 14.2c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-3.9-4.7-4.1-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.3 0 .5l-.4.6-.4.4c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.5.1.7-.1l.9-1.1c.2-.3.4-.2.7-.1l1.9.9c.3.1.5.2.5.3.1.2.1.7-.1 1.2Z"/></svg>';

/**
 * "Label: value" lines staff type on the product screen, as label => value pairs.
 */
function pl_specs( $product_id ) {
	$out = [];
	foreach ( preg_split( '/\R/', (string) get_post_meta( $product_id, '_pl_specs', true ) ) as $line ) {
		$parts = array_map( 'trim', explode( ':', $line, 2 ) );
		if ( count( $parts ) === 2 && $parts[0] !== '' ) {
			$out[ $parts[0] ] = $parts[1];
		}
	}
	return $out;
}

function pl_included( $product_id ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\R/', (string) get_post_meta( $product_id, '_pl_included', true ) ) ) ) );
}

/** Names of the attributes a customer chooses on a variable product, e.g. [ 'Vehicle class', 'Protection' ]. */
function pl_choices( WC_Product $product ) {
	if ( ! $product->is_type( 'variable' ) ) {
		return [];
	}
	$out = [];
	foreach ( $product->get_attributes() as $attr ) {
		if ( $attr->get_variation() ) {
			$out[] = wc_attribute_label( $attr->get_name(), $product );
		}
	}
	return $out;
}

/** Vehicle-class terms in their set order. */
function pl_vehicle_terms() {
	if ( ! taxonomy_exists( 'pa_vehicle' ) ) {
		return [];
	}
	$terms = get_terms( [ 'taxonomy' => 'pa_vehicle', 'hide_empty' => false, 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

/**
 * The cheapest purchasable variation of a product for one vehicle class (null = any class) whose
 * options include $option (null = any option).
 */
function pl_variation_for( WC_Product $product, $size, $option = null ) {
	if ( ! $product->is_type( 'variable' ) ) {
		return null;
	}
	$best = null;
	foreach ( $product->get_children() as $vid ) {
		$v = wc_get_product( $vid );
		if ( ! $v || ! $v->is_purchasable() ) {
			continue;
		}
		$a = $v->get_attributes();
		if ( ( $size !== null && ( $a['pa_vehicle'] ?? '' ) !== $size ) || ( $option !== null && ! in_array( $option, $a, true ) ) ) {
			continue;
		}
		if ( ! $best || (float) $v->get_price() < (float) $best->get_price() ) {
			$best = $v;
		}
	}
	return $best;
}

/** One estimator line: a fixed price, or a price per vehicle class. */
function pl_estimator_part( WC_Product $p, $option, array $sizes ) {
	$name = html_entity_decode( $p->get_name(), ENT_QUOTES ) . ( $option ? ' (' . $option . ')' : '' );
	if ( ! $p->is_type( 'variable' ) ) {
		return [ 'name' => $name, 'id' => $p->get_id(), 'price' => (float) $p->get_price() ];
	}
	if ( ! isset( $p->get_attributes()['pa_vehicle'] ) ) {
		$v = pl_variation_for( $p, null, $option );
		return $v ? [ 'name' => $name, 'id' => $v->get_id(), 'price' => (float) $v->get_price() ] : null;
	}
	$by = [];
	foreach ( $sizes as $s ) {
		$v = pl_variation_for( $p, $s, $option );
		if ( $v ) {
			$by[ $s ] = [ 'id' => $v->get_id(), 'price' => (float) $v->get_price() ];
		}
	}
	return [ 'name' => $name, 'by' => $by ];
}

/** Prices and variation ids for the estimator, read from the services so admin price edits show up there too. */
function pl_estimator_data() {
	$sizes = [];
	foreach ( pl_vehicle_terms() as $t ) {
		$sizes[ $t->slug ] = $t->name;
	}
	$tiers = [];
	foreach ( PL_TIERS as $key => [ $name, $sub, $parts ] ) {
		$tier = [ 'name' => $name, 'sub' => $sub, 'parts' => [], 'quote' => false ];
		foreach ( $parts as [ $slug, $option ] ) {
			$p    = pl_product( $slug );
			$part = $p ? pl_estimator_part( $p, $option, array_keys( $sizes ) ) : null;
			if ( ! $part ) {
				continue 2;
			}
			$part['slug']     = $slug;
			$tier['parts'][]  = $part;
			$tier['quote']    = $tier['quote'] || pl_is_quote( $p->get_id() );
		}
		$tiers[ $key ] = $tier;
	}
	$addons = [];
	foreach ( PL_ADDONS as [ $slug, $option, $label ] ) {
		$p    = pl_product( $slug );
		$part = $p && $p->is_purchasable() ? pl_estimator_part( $p, $option, array_keys( $sizes ) ) : null;
		if ( $part ) {
			$part['slug']     = $slug;
			$part['name']     = $label;
			$addons[ $slug ] = $part;
		}
	}
	return [ 'sizes' => $sizes, 'tiers' => $tiers, 'addons' => $addons, 'areas' => PL_AREAS, 'places' => PL_PLACES ];
}

function pl_badges_html( WC_Product $product ) {
	$time = get_post_meta( $product->get_id(), '_pl_time', true );
	$perk = get_post_meta( $product->get_id(), '_pl_perk', true );
	$h    = ( $perk ? '<span class="pl-badge pl-badge--perk">' . esc_html( $perk ) . '</span>' : '' ) . ( $time ? '<span class="pl-badge">' . esc_html( $time ) . '</span>' : '' );
	return $h ? '<div class="pl-badges">' . $h . '</div>' : '';
}

// "From KSh 12,000" instead of a price range.
add_filter( 'woocommerce_variable_price_html', function ( $html, $product ) {
	$min = $product->get_variation_price( 'min', true );
	$max = $product->get_variation_price( 'max', true );
	return $min === $max ? $html : '<span class="pl-from">From</span> ' . wc_price( $min );
}, 10, 2 );

/** The vehicle-class page being viewed (/vehicle/executive-suv/), if any. */
function pl_current_vehicle() {
	$q = get_queried_object();
	return $q instanceof WP_Term && $q->taxonomy === 'pa_vehicle' ? $q : null;
}

add_filter( 'woocommerce_product_single_add_to_cart_text', function ( $text, $product = null ) {
	return $product instanceof WC_Product && pl_is_quote( $product->get_id() ) ? 'Book an inspection' : 'Add to my booking';
}, 10, 2 );
add_filter( 'woocommerce_product_add_to_cart_text', function ( $t, $p ) {
	if ( ! $p || ! $p->is_in_stock() ) {
		return $t;
	}
	if ( pl_current_vehicle() && $p->is_type( 'variable' ) ) {
		return 'Book for this vehicle';
	}
	$choices = pl_choices( $p );
	return $choices ? 'Choose ' . strtolower( $choices[0] ) : 'Add to booking';
}, 10, 2 );
// On a vehicle-class page, cards open the service with that class already chosen.
add_filter( 'woocommerce_product_add_to_cart_url', function ( $url, $p ) {
	$term = pl_current_vehicle();
	return $term && $p->is_type( 'variable' ) && isset( $p->get_attributes()['pa_vehicle'] ) ? add_query_arg( 'attribute_pa_vehicle', $term->slug, $p->get_permalink() ) : $url;
}, 10, 2 );
add_filter( 'woocommerce_get_availability_text', fn( $text, $product ) => $product->is_in_stock() ? 'Taking bookings · ' . PL_HOURS : 'Fully booked', 10, 2 );

/* -------------------------------------------------------------------------
 * Service page
 * ---------------------------------------------------------------------- */

// Benefit badges, time and key facts above the options.
add_action( 'woocommerce_before_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$id    = $product->get_id();
	$perks = array_filter( array_map( 'trim', explode( '|', (string) get_post_meta( $id, '_pl_perks', true ) ) ) );
	$time  = get_post_meta( $id, '_pl_time', true );
	echo '<div class="pl-tags">';
	foreach ( $perks as $perk ) {
		echo '<span class="pl-tag">' . esc_html( $perk ) . '</span>';
	}
	echo ( $time ? '<span class="pl-tag pl-tag--time">' . esc_html( $time ) . '</span>' : '' ) . '</div>';
	if ( pl_is_quote( $id ) ) {
		echo '<p class="pl-note"><strong>Indicative price.</strong> Booking reserves an inspection at our Karen studio; we confirm the exact price before any work starts.</p>';
	}
	$keys = array_slice( pl_specs( $id ), 0, 4, true );
	if ( $keys ) {
		echo '<ul class="pl-keyspecs">';
		foreach ( $keys as $k => $v ) {
			echo '<li><span>' . esc_html( $k ) . '</span><strong>' . esc_html( $v ) . '</strong></li>';
		}
		echo '</ul>';
	}
} );

// Book on WhatsApp, the studio clip, add-ons and promises under the button.
add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$price = $product->is_type( 'variable' ) ? 'from ' . pl_money( $product->get_variation_price( 'min' ) ) : pl_money( $product->get_price() );
	$msg   = 'Hi Plush, I\'d like to book: ' . $product->get_name() . ' (' . $price . '). ' . $product->get_permalink();
	echo '<a class="pl-wa-order" data-pl-wa-product="' . esc_attr( $product->get_name() ) . '" data-pl-wa-price="' . esc_attr( $price ) . '" data-pl-wa-url="' . esc_url( $product->get_permalink() ) . '" href="' . esc_url( pl_wa_link( $msg ) ) . '" target="_blank" rel="noopener">' . PL_WA_ICON . 'Get an instant WhatsApp estimate</a>';

	$clip = get_post_meta( $product->get_id(), '_pl_clip', true );
	if ( $clip ) {
		echo '<figure class="pl-pdp-clip"><video src="' . esc_url( pl_clip_url( $clip ) ) . '" poster="' . esc_url( str_replace( '.mp4', '.webp', pl_clip_url( $clip ) ) ) . '" muted loop playsinline autoplay preload="metadata"></video><figcaption>Filmed in our Karen studio · <a href="' . esc_url( PL_IG ) . '" target="_blank" rel="noopener">more on Instagram</a></figcaption></figure>';
	}

	$pairs = array_filter( array_map( 'wc_get_product', $product->get_upsell_ids() ) );
	if ( $pairs ) {
		echo '<div class="pl-pairs"><p class="pl-pairs__title">Popular add-ons</p>';
		foreach ( $pairs as $p ) {
			$btn = $p->is_type( 'simple' ) && $p->is_in_stock()
				? '<button type="button" class="pl-pairs__add" data-pl-add="' . $p->get_id() . '" aria-label="Add ' . esc_attr( $p->get_name() ) . ' to your booking">+ Add</button>'
				: '<a class="pl-pairs__add" href="' . esc_url( $p->get_permalink() ) . '">View</a>';
			echo '<div class="pl-pairs__item"><a href="' . esc_url( $p->get_permalink() ) . '">' . $p->get_image( 'woocommerce_gallery_thumbnail', [ 'alt' => '' ] ) . '</a><div><a href="' . esc_url( $p->get_permalink() ) . '">' . esc_html( $p->get_name() ) . '</a><span>' . wp_kses_post( $p->get_price_html() ) . '</span></div>' . $btn . '</div>';
		}
		echo '</div>';
	}

	echo '<div class="pl-promise"><div><span aria-hidden="true">★</span><p><strong>IDA-accredited body shop</strong>International Detailing Association standards on every car.</p></div><div><span aria-hidden="true">⌖</span><p><strong>Karen studio or VIP pick-up</strong>Drop the car off, or we collect it covered and bring it back.</p></div><div><span aria-hidden="true">✓</span><p><strong>Pay when you collect</strong>Inspect the car first, then pay by M-Pesa or cash.</p></div></div>';
} );

// What's included, and booking & payment tabs.
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return $tabs;
	}
	$id       = $product->get_id();
	$specs    = pl_specs( $id );
	$included = pl_included( $id );
	if ( isset( $tabs['description'] ) ) {
		$tabs['description']['title'] = 'About this service';
	}
	if ( $specs || $included ) {
		$tabs['pl_included'] = [
			'title'    => 'What\'s included',
			'priority' => 5,
			'callback' => function () use ( $specs, $included ) {
				echo '<div class="pl-sheet">';
				if ( $included ) {
					echo '<div><h3>What we do</h3><ul class="pl-checks">';
					foreach ( $included as $s ) {
						echo '<li>' . esc_html( $s ) . '</li>';
					}
					echo '</ul></div>';
				}
				echo '<div><h3>Good to know</h3><table class="pl-spec-table"><tbody>';
				foreach ( $specs as $k => $v ) {
					echo '<tr><th>' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
				}
				echo '</tbody></table></div></div>';
			},
		];
	}
	$tabs['pl_booking'] = [
		'title'    => 'Booking & payment',
		'priority' => 30,
		'callback' => function () {
			echo '<ul><li><strong>Book online:</strong> add the service, then choose studio drop-off or VIP pick-up, the date and a drop-off time at checkout. We call to confirm.</li><li><strong>Where:</strong> our studio in Karen, Nairobi (<a href="' . esc_url( PL_MAPS ) . '" target="_blank" rel="noopener">map</a>). VIP covered pick-up and return on request.</li><li><strong>Hours:</strong> ' . esc_html( PL_HOURS ) . '.</li><li><strong>Pay:</strong> by M-Pesa or cash when you collect the car. Wraps, PPF, paint work and coatings take an M-Pesa deposit to book.</li><li><strong>WhatsApp:</strong> prefer to chat? Send photos of your car to ' . esc_html( PL_PHONE ) . ' for an estimate.</li></ul>';
		},
	];
	unset( $tabs['additional_information'] );
	return $tabs;
}, 20 );

/* -------------------------------------------------------------------------
 * Service cards
 * ---------------------------------------------------------------------- */

function pl_card_product( $instance ) {
	$id = $instance->context['postId'] ?? get_the_ID();
	return $id && ! is_admin() ? wc_get_product( $id ) : null;
}

// Hover image (first gallery photo), the video badge and the details pop-up on card images.
add_filter( 'render_block_woocommerce/product-image', function ( $content, $block, $instance ) {
	$product = pl_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$gallery = $product->get_gallery_image_ids();
	if ( $gallery ) {
		$alt     = wp_get_attachment_image( $gallery[0], 'woocommerce_thumbnail', false, [ 'class' => 'pl-alt-img', 'alt' => '', 'loading' => 'lazy' ] );
		$content = preg_replace( '#(<img[^>]*>)#', '$1' . $alt, $content, 1 );
	}
	$clip  = get_post_meta( $product->get_id(), '_pl_clip', true );
	$extra = ( $clip ? '<span class="pl-pov" aria-hidden="true">▶ Studio POV</span>' : '' )
		. sprintf( '<button type="button" class="pl-qv-btn" data-pl-qv="%1$d" data-pl-clip="%3$s" aria-label="Details of %2$s">%4$s</button>', $product->get_id(), esc_attr( $product->get_name() ), esc_url( pl_clip_url( $clip ) ), $clip ? 'Details &amp; video' : 'View details' );
	$pos   = strrpos( $content, '</div>' );
	return $pos === false ? $content : substr_replace( $content, $extra . '</div>', $pos, 6 );
}, 10, 3 );

// Category label above the title.
add_filter( 'render_block_core/post-title', function ( $content, $block, $instance ) {
	if ( empty( $block['attrs']['__woocommerceNamespace'] ) ) {
		return $content;
	}
	$product = pl_card_product( $instance );
	$badge   = $product ? get_post_meta( $product->get_id(), '_pl_badge', true ) : '';
	return ( $badge ? '<p class="pl-card-badge">' . esc_html( $badge ) . '</p>' : '' ) . $content;
}, 10, 3 );

// Benefit and time badges, "after inspection" on quote-led work, and on a vehicle page the price for that class.
add_filter( 'render_block_woocommerce/product-price', function ( $content, $block, $instance ) {
	$product = pl_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$term = pl_current_vehicle();
	if ( $term && $product->is_type( 'variable' ) && isset( $product->get_attributes()['pa_vehicle'] ) ) {
		$v = pl_variation_for( $product, $term->slug );
		if ( $v ) {
			$content = '<div class="wp-block-woocommerce-product-price"><div class="wc-block-components-product-price">' . ( count( pl_choices( $product ) ) > 1 ? '<span class="pl-from">From</span> ' : '' ) . wc_price( $v->get_price() ) . '</div></div>';
		}
	}
	$quote = pl_is_quote( $product->get_id() ) ? '<p class="pl-quote-note">Indicative · confirmed after inspection</p>' : '';
	return pl_badges_html( $product ) . $content . $quote;
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Home page and service lists
 * ---------------------------------------------------------------------- */

function pl_categories() {
	$terms = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ (int) get_option( 'default_product_cat' ) ], 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

// Service highlights: one tile per category, with the photo of its first service.
add_shortcode( 'pl_services', function () {
	$h   = '<div class="pl-services">';
	$sub = [
		'ida-detailing'            => 'Extensive interior & exterior · Ozone odour removal',
		'paint-correction-ceramic' => 'Rupes multi-stage correction · Gyeon ceramic',
		'vinyl-wraps'              => 'Colour change · Chrome delete · Commercial branding',
		'body-shop'                => 'Accident repair · Panel repaint · Full respray · Rims',
		'ppf-tint'                 => '7.5 mil self-healing PPF · Llumar IRX tint',
		'engine-steam'             => 'High-temperature steam · Anti-oxidant dressing',
		'add-ons'                  => 'Headlights · Leather · Black trims · Odours',
	];
	foreach ( pl_categories() as $t ) {
		$list = wc_get_products( [ 'category' => [ $t->slug ], 'limit' => 1, 'orderby' => 'menu_order', 'order' => 'ASC', 'status' => 'publish' ] );
		if ( $t->slug === 'add-ons' ) {
			$list = array_filter( [ pl_product( 'headlight-restoration' ) ] );
		}
		$img = $list ? reset( $list )->get_image( 'woocommerce_thumbnail', [ 'loading' => 'lazy', 'alt' => '' ] ) : '';
		$h  .= sprintf(
			'<a class="pl-service pl-service--%s" href="%s"><span class="pl-service__img">%s</span><span class="pl-service__txt"><strong>%s</strong><em>%s</em></span></a>',
			esc_attr( $t->slug ),
			esc_url( get_term_link( $t ) ),
			$img,
			esc_html( $t->name ),
			esc_html( $sub[ $t->slug ] ?? '' )
		);
	}
	return $h . '</div>';
} );

// "Book by vehicle type": a tile per class with its full-detail price, plus commercial fleets.
add_shortcode( 'pl_vehicles', function () {
	$full  = pl_product( 'full-detail' );
	$icons = [
		'saloon'        => 'M6 42h88M12 42v-6c0-3 2-4 5-5l9-9c2-2 4-3 7-3h26c3 0 5 1 7 3l9 8 11 2c3 1 4 3 4 6v4',
		'compact-suv'   => 'M6 42h88M10 42V30c0-3 2-5 5-5l9-9h36c3 0 5 1 7 3l8 7h8c3 0 5 2 5 5v11',
		'executive-suv' => 'M6 42h88M9 42V20c0-2 2-4 4-4h52c3 0 5 1 7 3l6 7h7c3 0 5 2 5 5v11M30 16v10M52 16v10',
		'exotic'        => 'M6 42h88M8 42v-4c0-3 2-4 5-5l14-8c3-2 6-3 10-3h20c4 0 7 1 10 3l10 6 10 2c3 1 4 3 4 5v4',
	];
	$examples = [ 'saloon' => 'Golf GTI, C-Class, Jetta, XF', 'compact-suv' => 'RAV4, X3, Q5, Macan', 'executive-suv' => 'Land Cruiser, Range Rover, Defender, G-Class', 'exotic' => 'X3 M, RS 6, AMG, Porsche' ];
	$h = '<div class="pl-vehicles">';
	foreach ( pl_vehicle_terms() as $t ) {
		$v  = $full ? pl_variation_for( $full, $t->slug ) : null;
		$h .= sprintf(
			'<a class="pl-vehicle" href="%s"><svg viewBox="0 0 100 52" aria-hidden="true"><path d="%s"/><circle cx="28" cy="42" r="7"/><circle cx="72" cy="42" r="7"/></svg><strong>%s</strong><em>%s</em>%s</a>',
			esc_url( get_term_link( $t ) ),
			esc_attr( $icons[ $t->slug ] ?? $icons['saloon'] ),
			esc_html( $t->name ),
			esc_html( $examples[ $t->slug ] ?? '' ),
			$v ? '<span>Full detail <b>' . esc_html( pl_money( $v->get_price() ) ) . '</b></span>' : ''
		);
	}
	$h .= '<a class="pl-vehicle pl-vehicle--fleet" href="/fleet-commercial/"><svg viewBox="0 0 100 52" aria-hidden="true"><path d="M6 42h88M8 42V14c0-2 2-4 4-4h48v32M60 20h18l12 12v10"/><circle cx="24" cy="42" r="7"/><circle cx="76" cy="42" r="7"/></svg><strong>Commercial &amp; custom fleets</strong><em>Company cars, vans &amp; branded fleets</em><span>Get a fleet quote →</span></a>';
	return $h . '</div>';
} );

// Category and vehicle-class chips above shop, category, vehicle and search pages.
function pl_chip( $label, $url, $on, $count = null, $small = false ) {
	return sprintf( '<a class="pl-chip%s%s" href="%s">%s%s</a>', $small ? ' pl-chip--sm' : '', $on ? ' is-on' : '', esc_url( $url ), esc_html( $label ), $count === null ? '' : ' <em>' . (int) $count . '</em>' );
}
add_shortcode( 'pl_filters', function () {
	$current = get_queried_object();
	$cur_id  = $current instanceof WP_Term ? $current->term_id : 0;
	$h = '<nav class="pl-filters" aria-label="Filter services"><div class="pl-filters__row">';
	$h .= pl_chip( 'All services', wc_get_page_permalink( 'shop' ), is_shop() );
	foreach ( pl_categories() as $t ) {
		$h .= pl_chip( $t->name, get_term_link( $t ), $t->term_id === $cur_id, $t->count );
	}
	$h .= '</div><div class="pl-filters__row"><span>Prices for</span>';
	foreach ( pl_vehicle_terms() as $t ) {
		$h .= pl_chip( $t->name, get_term_link( $t ), $t->term_id === $cur_id, null, true );
	}
	return $h . '</div></nav>';
} );

// #Plushed showcase: their real Google reviews (5.0 from 2), the 2025 award and the Instagram community.
add_shortcode( 'pl_reviews', function () {
	$reviews = [
		[ 'Got a wrap done and the quality of the wraps is perfect. Amazing customer service as well! Great location.', 'Hadassah M', 'Google review · vinyl wrap' ],
		[ 'Amazing spot. Price assessment: great price.', 'Vernon Kanampiu', 'Google review' ],
	];
	$h  = '<div class="pl-reviews"><a class="pl-reviews__score" href="' . esc_url( PL_MAPS ) . '" target="_blank" rel="noopener"><strong>5.0</strong><span class="pl-stars" aria-label="5 out of 5">★★★★★</span><span>on Google</span><em>See Plush Karen on Google Maps →</em></a><div class="pl-reviews__list">';
	foreach ( $reviews as [ $text, $who, $where ] ) {
		$h .= '<figure class="pl-review"><span class="pl-stars" aria-label="5 out of 5">★★★★★</span><blockquote>' . esc_html( $text ) . '</blockquote><figcaption><strong>' . esc_html( $who ) . '</strong><span>' . esc_html( $where ) . '</span></figcaption></figure>';
	}
	$h .= '<figure class="pl-review pl-review--award"><img src="' . esc_url( get_stylesheet_directory_uri() . '/assets/photos/award.webp' ) . '" alt="Plush Kenya\'s Excellent Motors Awards East Africa certificate and trophy" width="720" height="900" loading="lazy"><figcaption><strong>Best Dealership Customer Service 2025</strong><span>Excellent Motors Awards East Africa · 5-Star Rating Distinction</span></figcaption></figure>';
	$h .= '<a class="pl-review pl-review--ig" href="' . esc_url( PL_IG ) . '" target="_blank" rel="noopener"><strong>#Plushed</strong><span>3,400+ people follow our transformations on Instagram</span><em>@plush.kenya →</em></a>';
	return $h . '</div></div>';
} );

// Before / after sliders: their own before-and-after shots (headlights; a Prado door card).
add_shortcode( 'pl_before_after', function () {
	$dir   = get_stylesheet_directory_uri() . '/assets/photos/';
	$pairs = [
		[ 'ba-lights', 'Headlight restoration', 'Yellowed', 'Restored', 'Oxidised, yellowed headlight before restoration', 'The same headlight, sanded, polished and UV-sealed' ],
		[ 'ba-door', 'Interior restoration', 'Before', 'Plushed', 'Stained door card before interior detailing', 'The same door card after Plush\'s interior restoration' ],
	];
	$h = '<div class="pl-ba-tabs" role="tablist">';
	foreach ( $pairs as $i => [ $key, $title ] ) {
		$h .= '<button type="button" role="tab" aria-selected="' . ( $i ? 'false' : 'true' ) . '" data-pl-ba-tab="' . $i . '"' . ( $i ? '' : ' class="is-on"' ) . '>' . esc_html( $title ) . '</button>';
	}
	$h .= '</div>';
	foreach ( $pairs as $i => [ $key, $title, $l, $r, $alt_before, $alt_after ] ) {
		$h .= '<figure class="pl-ba" data-pl-ba data-pl-ba-pane="' . $i . '" style="--pos:50%"' . ( $i ? ' hidden' : '' ) . '><img src="' . esc_url( $dir . $key . '-after.webp' ) . '" alt="' . esc_attr( $alt_after ) . '" width="720" height="720" loading="lazy"><div class="pl-ba__before"><img src="' . esc_url( $dir . $key . '-before.webp' ) . '" alt="' . esc_attr( $alt_before ) . '" width="720" height="720" loading="lazy"></div><span class="pl-ba__label pl-ba__label--l">' . esc_html( $l ) . '</span><span class="pl-ba__label pl-ba__label--r">' . esc_html( $r ) . '</span><span class="pl-ba__handle" aria-hidden="true"></span><input type="range" min="0" max="100" value="50" aria-label="' . esc_attr( 'Slide to compare: ' . $title ) . '"></figure>';
	}
	return '<div class="pl-ba-wrap">' . $h . '</div>';
} );

// Studio POV: muted loops filmed in their studio, each linking to its service.
add_shortcode( 'pl_clips', function () {
	$clips = [
		[ 'steam', 'Steamed engine bay', 'steamed-engine-bay' ],
		[ 'wrap', 'Vinyl wrap install', 'colour-change-wrap' ],
		[ 'ppf', 'Self-healing PPF', 'paint-protection-film' ],
		[ 'paint', 'Booth paint work', 'collision-repair-repaint' ],
		[ 'polish', 'Rupes paint correction', 'paint-correction' ],
	];
	$h = '<div class="pl-clips">';
	foreach ( $clips as [ $clip, $label, $slug ] ) {
		$p  = pl_product( $slug );
		$h .= '<a class="pl-clip" href="' . esc_url( $p ? $p->get_permalink() : '#' ) . '"><video src="' . esc_url( pl_clip_url( $clip ) ) . '" poster="' . esc_url( str_replace( '.mp4', '.webp', pl_clip_url( $clip ) ) ) . '" muted loop playsinline autoplay preload="none"></video><span>' . esc_html( $label ) . '</span></a>';
	}
	return $h . '</div>';
} );

// Package customizer: vehicle class × package × add-ons × drop-off or pick-up. pl.js does the maths, the booking and WhatsApp.
add_shortcode( 'pl_estimator', function () {
	$est = pl_estimator_data();
	if ( ! $est['tiers'] || ! $est['sizes'] ) {
		return '';
	}
	$opt = fn( $v, $label ) => '<option value="' . esc_attr( $v ) . '">' . esc_html( $label ) . '</option>';
	ob_start();
	?>
	<form class="pl-est" data-pl-estimator novalidate>
		<ol class="pl-est__steps" aria-hidden="true"><li class="is-on">Vehicle</li><li>Package</li><li>Add-ons</li><li>Drop-off</li></ol>

		<fieldset class="pl-est__step" data-step="1">
			<legend><span>1</span> Your vehicle</legend>
			<div class="pl-est__cards pl-est__cards--4">
				<?php $i = 0; foreach ( $est['sizes'] as $slug => $name ) : ?>
					<label><input type="radio" name="size" value="<?php echo esc_attr( $slug ); ?>"<?php echo $i++ ? '' : ' checked'; ?>><strong><?php echo esc_html( $name ); ?></strong></label>
				<?php endforeach; ?>
			</div>
		</fieldset>

		<fieldset class="pl-est__step" data-step="2">
			<legend><span>2</span> Service tier</legend>
			<div class="pl-est__cards">
				<?php foreach ( $est['tiers'] as $key => $t ) : ?>
					<label><input type="radio" name="tier" value="<?php echo esc_attr( $key ); ?>"<?php echo $key === 'restoration' ? ' checked' : ''; ?>><strong><?php echo esc_html( $t['name'] ); ?></strong><em><?php echo esc_html( $t['sub'] ); ?></em><b data-pl-tier-price="<?php echo esc_attr( $key ); ?>"></b><?php echo $t['quote'] ? '<small>Indicative · confirmed after inspection</small>' : ''; ?></label>
				<?php endforeach; ?>
			</div>
		</fieldset>

		<fieldset class="pl-est__step" data-step="3">
			<legend><span>3</span> Add-ons</legend>
			<div class="pl-est__addons">
				<?php foreach ( $est['addons'] as $slug => $a ) : ?>
					<label data-pl-addon="<?php echo esc_attr( $slug ); ?>"><input type="checkbox" name="addon" value="<?php echo esc_attr( $slug ); ?>"><span><?php echo esc_html( $a['name'] ); ?></span><b data-pl-addon-price></b></label>
				<?php endforeach; ?>
			</div>
		</fieldset>

		<fieldset class="pl-est__step" data-step="4">
			<legend><span>4</span> Studio drop-off or VIP pick-up?</legend>
			<div class="pl-est__grid">
				<label>Service type<select name="place"><?php foreach ( PL_PLACES as $k => $v ) echo $opt( $k, $v ); ?></select></label>
				<label data-pl-area hidden>Pick-up area<select name="area"><?php foreach ( array_slice( PL_AREAS, 1, null, true ) as $k => $v ) echo $opt( $k, $v ); ?></select></label>
			</div>
		</fieldset>

		<div class="pl-est__result" aria-live="polite">
			<div>
				<p class="pl-est__label">Your estimate</p>
				<p class="pl-est__total" data-pl-est-total>KSh 0</p>
				<p class="pl-est__summary" data-pl-est-summary></p>
				<p class="pl-small" data-pl-est-note></p>
			</div>
			<div class="pl-est__actions">
				<button type="button" class="wp-element-button" data-pl-est-book>Book your service session</button>
				<a class="pl-wa-order pl-est__wa" data-pl-est-wa href="<?php echo esc_url( pl_wa_link() ); ?>" target="_blank" rel="noopener"><?php echo PL_WA_ICON; ?>Get this quote on WhatsApp</a>
			</div>
		</div>
	</form>
	<?php
	return ob_get_clean();
} );

// Fleet, branding & commercial request: composes a WhatsApp message (nothing is stored on the site).
add_shortcode( 'pl_fleet_form', function () {
	$sel = fn( $name, array $opts ) => '<select name="' . $name . '">' . implode( '', array_map( fn( $o ) => '<option>' . esc_html( $o ) . '</option>', $opts ) ) . '</select>';
	ob_start();
	?>
	<form class="pl-est pl-fleet" data-pl-fleet>
		<div class="pl-est__grid">
			<label>Company / organisation<input type="text" name="company" autocomplete="organization" required></label>
			<label>Your name<input type="text" name="name" autocomplete="name" required></label>
			<label>Phone<input type="tel" name="phone" autocomplete="tel" inputmode="tel" required></label>
			<label>Number of vehicles<input type="number" name="count" min="2" max="500" value="5" inputmode="numeric"></label>
			<label>Mostly<?php echo $sel( 'types', [ 'Saloons & pool cars', 'Executive SUVs', 'Vans & pickups', 'A mix' ] ); ?></label>
			<label>Service<?php echo $sel( 'service', [ 'Detailing', 'Commercial branding', 'PPF & tint', 'Body shop & paint work', 'Not sure: advise us' ] ); ?></label>
			<label>How often<?php echo $sel( 'often', [ 'Once (a one-off job)', 'Every month', 'Every quarter' ] ); ?></label>
			<label>Pick-up needed?<?php echo $sel( 'pickup', [ 'No, we drop off in Karen', 'Yes, collect from our premises' ] ); ?></label>
		</div>
		<label class="pl-fleet__notes">Anything else (branding artwork, working hours, insurance jobs)<textarea name="notes" rows="3"></textarea></label>
		<div class="pl-est__result">
			<p class="pl-small">We reply on WhatsApp with a per-vehicle price and a schedule that keeps your vehicles on the road.</p>
			<button type="submit" class="pl-wa-order pl-est__wa"><?php echo PL_WA_ICON; ?>Send fleet request on WhatsApp</button>
		</div>
	</form>
	<?php
	return ob_get_clean();
} );

// Details pop-up (filled in by pl.js) and the floating WhatsApp button.
add_action( 'wp_footer', function () {
	echo '<dialog id="pl-qv" class="pl-dialog pl-qv" aria-label="Service details"><form method="dialog"><button class="pl-dialog__close" aria-label="Close">×</button></form><div data-pl-qv-body></div></dialog>';
	echo '<a class="pl-wa-float" href="' . esc_url( pl_wa_link( 'Hi Plush, I\'d like an estimate for my car:' ) ) . '" target="_blank" rel="noopener" aria-label="Chat with Plush on WhatsApp">' . PL_WA_ICON . '</a>';
} );

/* -------------------------------------------------------------------------
 * Cart (the booking), checkout, confirmation
 * ---------------------------------------------------------------------- */

function pl_cart_note_html() {
	return '<div class="pl-cart-note"><strong>Next:</strong> choose studio drop-off or VIP pick-up, the date and a drop-off time. Nothing is paid online: you pay when you collect.</div>';
}
function pl_wa_cart_html() {
	return '<button type="button" class="pl-wa-cart" data-pl-wa-cart>' . PL_WA_ICON . 'Send booking details to Plush WhatsApp</button>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => pl_cart_note_html() . $c );
add_filter( 'render_block_woocommerce/proceed-to-checkout-block', fn( $c ) => $c . pl_wa_cart_html() );
add_filter( 'render_block_woocommerce/mini-cart-contents', function ( $c ) {
	return preg_replace( '#(<div[^>]*wp-block-woocommerce-mini-cart-items-block)#', pl_cart_note_html() . '$1', $c, 1 );
} );
add_filter( 'render_block_woocommerce/mini-cart-footer-block', fn( $c ) => $c . '<div class="pl-wa-cart-wrap">' . pl_wa_cart_html() . '</div>' );

// Booking words on the cart and checkout buttons.
add_filter( 'render_block_data', function ( $block ) {
	$labels = [
		'woocommerce/checkout-actions-block'          => [ 'placeOrderButtonLabel', 'Confirm my booking' ],
		'woocommerce/proceed-to-checkout-block'       => [ 'buttonLabel', 'Choose date & drop-off' ],
		'woocommerce/mini-cart-title-label-block'     => [ 'label', 'Your booking' ],
		'woocommerce/mini-cart-checkout-button-block' => [ 'checkoutButtonLabel', 'Book now' ],
		'woocommerce/mini-cart-cart-button-block'     => [ 'cartButtonLabel', 'View booking' ],
	];
	if ( isset( $labels[ $block['blockName'] ] ) ) {
		[ $attr, $text ]          = $labels[ $block['blockName'] ];
		$block['attrs'][ $attr ] = $text;
	}
	// Checkout steps in booking words: 1 you, 2 your car & appointment, 3 payment.
	$steps = [
		'woocommerce/checkout-contact-information-block'    => [ 'Your contact details', 'We send your booking confirmation here.' ],
		'woocommerce/checkout-billing-address-block'        => [ 'Your name & pick-up address', 'The address is only needed if we collect your car.' ],
		'woocommerce/checkout-additional-information-block' => [ 'Your vehicle & appointment', 'Make, model and registration, studio drop-off or VIP pick-up, and when.' ],
		'woocommerce/checkout-payment-block'                => [ 'How you\'ll pay', 'Nothing is paid online.' ],
	];
	if ( isset( $steps[ $block['blockName'] ] ) ) {
		[ $block['attrs']['title'], $block['attrs']['description'] ] = $steps[ $block['blockName'] ];
	}
	// The car and the appointment come before payment.
	if ( $block['blockName'] === 'woocommerce/checkout-fields-block' && ! empty( $block['innerBlocks'] ) ) {
		$names = array_column( $block['innerBlocks'], 'blockName' );
		$info  = array_search( 'woocommerce/checkout-additional-information-block', $names, true );
		$pay   = array_search( 'woocommerce/checkout-payment-block', $names, true );
		if ( $info !== false && $pay !== false && $info > $pay ) {
			$moved = array_splice( $block['innerBlocks'], $info, 1 );
			array_splice( $block['innerBlocks'], $pay, 0, $moved );
		}
	}
	return $block;
} );

// Add-ons are shown as "Popular add-ons" next to the button, so skip WooCommerce's own upsell row.
add_action( 'init', fn() => remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 ) );

// Vehicle-class pages: a readable breadcrumb instead of "Product Vehicle class".
add_filter( 'woocommerce_get_breadcrumb', function ( $crumbs ) {
	if ( pl_current_vehicle() ) {
		foreach ( $crumbs as $i => $c ) {
			if ( str_contains( (string) $c[0], 'Vehicle class' ) ) {
				$crumbs[ $i ] = [ 'Prices by vehicle', home_url( '/#vehicles' ) ];
			}
		}
	}
	return $crumbs;
} );

/** The next three weeks as booking dates, Sundays left out (closed): Y-m-d => "Thu 8 Oct". */
function pl_booking_dates() {
	$out = [];
	$day = new DateTime( 'tomorrow', wp_timezone() );
	for ( $i = 0; $i < 21; $i++ ) {
		$n = $day->format( 'N' );
		if ( $n !== '7' ) {
			$out[ $day->format( 'Y-m-d' ) ] = $day->format( 'D j M' ) . ( $n === '6' ? ' (closes 2 pm)' : '' );
		}
		$day->modify( '+1 day' );
	}
	return $out;
}

// What the studio needs to know: field => [ label, short label, options (null = text), required ].
function pl_checkout_fields() {
	return [
		'pl/vehicle' => [ 'Vehicle make & model (e.g. Range Rover Sport)', 'Vehicle', null, true ],
		'pl/plate'   => [ 'Registration & colour (e.g. KDA 123A, white)', 'Registration & colour', null, false ],
		'pl/place'   => [ 'Studio drop-off or VIP pick-up?', 'Service type', PL_PLACES, true ],
		'pl/area'    => [ 'Pick-up area (VIP pick-up only)', 'Pick-up area', PL_AREAS, true ],
		'pl/date'    => [ 'Preferred date', 'Date', pl_booking_dates(), true ],
		'pl/time'    => [ 'Drop-off / pick-up time', 'Time', PL_SLOTS, true ],
	];
}
add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
		return;
	}
	foreach ( pl_checkout_fields() as $id => [ $label, , $options, $required ] ) {
		$field = [ 'id' => $id, 'label' => $label, 'location' => 'order', 'type' => $options ? 'select' : 'text', 'required' => $required ];
		if ( $options ) {
			$field['options'] = array_map( fn( $v, $l ) => [ 'value' => (string) $v, 'label' => $l ], array_keys( $options ), $options );
		}
		woocommerce_register_additional_checkout_field( $field );
	}
} );

function pl_booking_code( WC_Order $order ) {
	return 'PL-' . $order->get_order_number() . '-' . strtoupper( substr( $order->get_order_key(), -4 ) );
}
/** Booking details from the checkout fields, as short label => readable value. */
function pl_booking_details( WC_Order $order ) {
	$out = [];
	foreach ( pl_checkout_fields() as $key => [ , $label, $options ] ) {
		$value = (string) $order->get_meta( '_wc_other/' . $key );
		if ( $value !== '' && ! ( $key === 'pl/area' && $value === 'none' ) ) {
			$out[ $label ] = $options[ $value ] ?? $value;
		}
	}
	return $out;
}
function pl_whatsapp_order_link( WC_Order $order ) {
	$lines = [ 'Hi Plush, I just booked online (' . pl_booking_code( $order ) . '):' ];
	foreach ( $order->get_items() as $item ) {
		$lines[] = '• ' . html_entity_decode( $item->get_name(), ENT_QUOTES ) . ( $item->get_quantity() > 1 ? ' × ' . $item->get_quantity() : '' ) . ' – ' . pl_money( $item->get_total() );
	}
	$lines[] = 'Total: ' . pl_money( $order->get_total() ) . ', ' . $order->get_payment_method_title();
	foreach ( pl_booking_details( $order ) as $label => $value ) {
		$lines[] = $label . ': ' . $value;
	}
	$address = trim( implode( ', ', array_filter( [ $order->get_billing_address_1(), $order->get_billing_city() ] ) ) );
	if ( $address ) {
		$lines[] = 'Pick-up address: ' . $address;
	}
	$lines[] = 'Name: ' . $order->get_formatted_billing_full_name() . ', ' . $order->get_billing_phone();
	return pl_wa_link( implode( "\n", $lines ) );
}
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) { // phpcs:ignore
		return $content;
	}
	$d     = pl_booking_details( $order );
	$when  = implode( ' · ', array_filter( [ $d['Date'] ?? '', $d['Time'] ?? '', $d['Service type'] ?? '' ] ) );
	$valet = ( (string) $order->get_meta( '_wc_other/pl/place' ) ) === 'valet';
	return $content . '<div class="pl-thanks"><p class="pl-thanks__code">Booking number <strong>' . esc_html( pl_booking_code( $order ) ) . '</strong></p>' . ( $when ? '<p class="pl-thanks__when">' . esc_html( $when ) . '</p>' : '' ) . '<ol><li>We call you shortly to confirm the slot' . ( $valet ? ' and the pick-up' : '' ) . '.</li><li>' . ( $valet ? 'Our driver collects your car under cover and brings it to the studio.' : 'Drop your car at our studio in Karen (<a href="' . esc_url( PL_MAPS ) . '" target="_blank" rel="noopener">map</a>).' ) . '</li><li>Inspect the finished car, then pay by M-Pesa or cash.</li></ol><a class="wp-element-button pl-wa-btn" href="' . esc_attr( pl_whatsapp_order_link( $order ) ) . '" target="_blank" rel="noopener">' . PL_WA_ICON . 'Send booking details to Plush WhatsApp</a></div>';
} );
add_action( 'woocommerce_admin_order_data_after_order_details', function ( $order ) {
	echo '<p class="form-field form-field-wide"><strong>Booking number:</strong> ' . esc_html( pl_booking_code( $order ) ) . '</p>';
} );

// Staff edit the card badges, the facts, what's included and the studio clip on the product screen.
add_action( 'woocommerce_product_options_general_product_data', function () {
	woocommerce_wp_text_input( [ 'id' => '_pl_badge', 'label' => 'Card label', 'description' => 'Small label above the name, e.g. "Most booked".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_pl_perk', 'label' => 'Card badge', 'description' => 'One benefit shown on the card, e.g. "10-year warranty".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_pl_perks', 'label' => 'Benefit badges', 'description' => 'Shown on the service page, separated by |, e.g. "Self-healing film | 10-year warranty".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_pl_time', 'label' => 'Time', 'description' => 'e.g. "1 day in the studio".', 'desc_tip' => true ] );
	woocommerce_wp_select( [ 'id' => '_pl_clip', 'label' => 'Studio clip', 'options' => [ '' => 'None', 'steam' => 'Engine steam', 'wrap' => 'Wrap install', 'ppf' => 'PPF fitting', 'paint' => 'Booth paint work', 'polish' => 'Paint correction' ] ] );
	woocommerce_wp_checkbox( [ 'id' => '_pl_quote', 'label' => 'Price after inspection', 'description' => 'Shows the price as indicative and the button as "Book an inspection".' ] );
	woocommerce_wp_textarea_input( [ 'id' => '_pl_specs', 'label' => 'Good to know', 'rows' => 5, 'description' => 'One per line, as "Label: value". The first four also show next to the price.' ] );
	woocommerce_wp_textarea_input( [ 'id' => '_pl_included', 'label' => 'What\'s included', 'rows' => 8, 'description' => 'One item per line.' ] );
	echo '<p class="form-field"><em>Prices by vehicle: the "Vehicle class" attribute makes the variations; set each variation\'s price under Variations. "Popular add-ons" = Linked Products → Upsells.</em></p>';
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_pl_badge', '_pl_perk', '_pl_perks', '_pl_time', '_pl_clip' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) { // phpcs:ignore
			$product->update_meta_data( $k, sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) ); // phpcs:ignore
		}
	}
	$product->update_meta_data( '_pl_quote', isset( $_POST['_pl_quote'] ) ? 'yes' : 'no' ); // phpcs:ignore
	foreach ( [ '_pl_specs', '_pl_included' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) { // phpcs:ignore
			$product->update_meta_data( $k, sanitize_textarea_field( wp_unslash( $_POST[ $k ] ) ) ); // phpcs:ignore
		}
	}
} );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

// Kenyan addresses: no postcode or county. The address only matters when Plush collects the car.
add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	$locale['KE']['postcode']  = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['state']     = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['address_2'] = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['address_1'] = [ 'label' => 'Pick-up address (only for VIP pick-up)', 'required' => false ];
	$locale['KE']['city']      = [ 'label' => 'Area / estate', 'required' => false ];
	$locale['KE']['phone']     = [ 'required' => true ];
	return $locale;
} );

// Booking words for WooCommerce's shop words.
add_filter( 'gettext', function ( $text, $original, $domain ) {
	if ( $domain !== 'woocommerce' ) {
		return $text;
	}
	return [
		'Related products'  => 'You may also like',
		'Continue shopping' => 'Keep browsing services',
		'Order received'    => 'Booking received',
		'Thank you. Your order has been received.' => 'Thank you. Your booking has been received.',
	][ $original ] ?? $text;
}, 10, 3 );
add_filter( 'ngettext', function ( $text, $single, $plural, $number, $domain ) {
	return $domain === 'woocommerce' && $single === '%s has been added to your cart.' ? '%s has been added to your booking.' : $text;
}, 10, 5 );

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
// Real hosting uses MySQL, where this never triggers.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

// Browser tab icon.
add_action( 'wp_head', function () {
	if ( has_site_icon() ) {
		return;
	}
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n<meta name=\"theme-color\" content=\"#121212\">\n";
} );

// Shortcode blocks: run the shortcode as is. The block's automatic paragraphs break the
// estimator's and reviews' grids with stray <p> and <br> tags.
add_filter( 'pre_render_block', function ( $pre, $block ) {
	return ( $block['blockName'] ?? '' ) === 'core/shortcode' ? do_shortcode( trim( $block['innerHTML'] ) ) : $pre;
}, 10, 2 );

// Templates use root-relative links ("/shop/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) {
		return $content;
	}
	return preg_replace( '#\b(href|src|poster)="/(?!/)#', '$1="' . $home, $content );
} );

